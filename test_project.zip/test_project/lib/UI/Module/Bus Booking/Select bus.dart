import 'package:flutter/material.dart';
import 'package:test_project/UI/Module/Bus%20Booking/Nearbystop.dart';
import 'package:test_project/UI/Module/Bus%20Booking/payment.dart';

class MyBus extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      color: Colors.blue,
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          title: Text('Select Bus'),
          leading: IconButton(
            icon: Icon(
              Icons.arrow_back,
              color: Colors.white,
            ),
            onPressed: () {
              Navigator.pop(
                  context,
                  MaterialPageRoute(
                    builder: (context) => NearbyStop(),
                  ));
            },
          ),
        ),
        body: SingleChildScrollView(
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    height: 150,
                    margin: const EdgeInsets.only(top: 20.0),
                    child: const Image(
                      image: AssetImage("assets/logo.png"),
                      height: 190,
                      width: 190,
                    ),
                  ),
                ],
              ),
              const SizedBox(
                height: 30,
              ),
              const Center(
                child: Text(
                  "Choose Bus",
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    width: 350,
                    margin: const EdgeInsets.only(top: 20.0),
                    decoration: BoxDecoration(
                      color: Colors.lightBlue[100],
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => payment(),
                          ),
                        );
                      },
                      child: Row(
                        children: [
                          Column(
                            children: [
                              Row(
                                children: [
                                  const SizedBox(height: 3),
                                  Image.asset(
                                    'assets/bus-stop.png',
                                    width: 60,
                                    height: 60,
                                  ),
                                  Column(
                                    children: [
                                      const Text(
                                        'LSV1297',
                                        style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 19,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                      const Text(
                                        '6:20am-12:00pm',
                                        style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 14,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ],
                          ),
                          SizedBox(
                            width: 35,
                          ),
                          Column(
                            children: [
                              const SizedBox(height: 8),
                              const Text(
                                'Islamabad Express Way',
                                style: TextStyle(
                                  fontSize: 14,
                                ),
                              ),
                              const Text(
                                '4 Remaining',
                                style: TextStyle(
                                  fontSize: 14,
                                ),
                              ),
                              const Text(
                                'Bus Description',
                                style: TextStyle(
                                  fontSize: 14,
                                  color: Colors.blue,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 25,
                  ),

                  //222

                  Container(
                    width: 350,
                    decoration: BoxDecoration(
                      color: Colors.lightBlue[100],
                      borderRadius: BorderRadius.circular(20),
                    ),
                    margin: const EdgeInsets.only(top: 20.0),
                    child: Row(
                      children: [
                        Column(
                          children: [
                            Row(
                              children: [
                                const SizedBox(height: 3),
                                Image.asset(
                                  'assets/bus-stop.png',
                                  width: 60,
                                  height: 60,
                                ),
                                Column(
                                  children: [
                                    const Text(
                                      'LSV1237',
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 19,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    const Text(
                                      '8:00am-2:00pm',
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 14,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ],
                        ),
                        SizedBox(
                          width: 35,
                        ),
                        Column(
                          children: [
                            const SizedBox(height: 8),
                            const Text(
                              'Islamabad Express Way',
                              style: TextStyle(
                                fontSize: 14,
                              ),
                            ),
                            const Text(
                              '24 Remaining',
                              style: TextStyle(
                                fontSize: 14,
                              ),
                            ),
                            const Text(
                              'Bus Description',
                              style: TextStyle(
                                fontSize: 14,
                                color: Colors.blue,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 25,
                  ),
                  Container(
                    width: 350,
                    decoration: BoxDecoration(
                      color: Colors.lightBlue[100],
                      borderRadius: BorderRadius.circular(20),
                    ),
                    margin: const EdgeInsets.only(top: 20.0),
                    child: Row(
                      children: [
                        Column(
                          children: [
                            Row(
                              children: [
                                const SizedBox(height: 3),
                                Image.asset(
                                  'assets/bus-stop.png',
                                  width: 60,
                                  height: 60,
                                ),
                                Column(
                                  children: [
                                    const Text(
                                      'LSV1256',
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 19,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    const Text(
                                      '10:00am-4:10pm',
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 14,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ],
                        ),
                        SizedBox(
                          width: 35,
                        ),
                        Column(
                          children: [
                            const SizedBox(height: 8),
                            const Text(
                              'Islamabad Express Way',
                              style: TextStyle(
                                fontSize: 14,
                              ),
                            ),
                            const Text(
                              '30 Remaining',
                              style: TextStyle(
                                fontSize: 14,
                              ),
                            ),
                            const Text(
                              'Bus Description',
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                color: Colors.blue,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
