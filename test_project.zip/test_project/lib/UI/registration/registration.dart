import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'Users.dart';
import 'auth_controller.dart';
import 'login.dart';

// ignore: camel_case_types
class registration extends StatelessWidget {
  const registration({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Register',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: Register(),
    );
  }
}

class Register extends StatefulWidget {
  @override
  State<Register> createState() => _RegisterState();
}

class _RegisterState extends State<Register> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          color: Colors.white,
          onPressed: () {
            Navigator.pop(
              context,
              MaterialPageRoute(
                builder: (context) => User(),
              ),
            );
          },
        ),
        title: const Text('Registration'),
      ),
      body: OppositeTriangle(),
    );
  }
}

class OppositeTriangle extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var emailController = TextEditingController();
    var passwordController = TextEditingController();
    return CustomPaint(
      painter: TrianglePainter(),
      child: Stack(
        children: [
          Positioned(
            top: 10,
            left: 120,
            child: Container(
              width: 150,
              height: 150,
              child: Image.asset(
                'assets/logo.png',
              ),
            ),
          ),
          Positioned(
            top: 250,
            left: 20,
            right: 20,
            child: Scrollbar(
              child: Container(
                height: 400, // Set a fixed height
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 20),
                        child: TextFormField(
                          decoration: InputDecoration(
                            hintText: 'Full Name',
                            fillColor: Colors.white,
                            filled: true,
                            suffixIcon: Icon(Icons.person),
                            prefixIcon: Icon(
                              Icons.person,
                              color: Colors.indigoAccent,
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: const Color(0xffE4E7EB)),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: Colors.indigoAccent),
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 15),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        child: TextFormField(
                          decoration: InputDecoration(
                            hintText: 'User Name',
                            fillColor: Colors.white,
                            filled: true,
                            suffixIcon: Icon(Icons.person),
                            prefixIcon: Icon(
                              Icons.person,
                              color: Colors.indigoAccent,
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide:
                                  const BorderSide(color: Color(0xffE4E7EB)),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderSide:
                                  const BorderSide(color: Colors.indigoAccent),
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                        ),
                      ),

                      SizedBox(height: 15),
                      Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 10),
                        child: TextFormField(
                          controller: emailController,
                          decoration: InputDecoration(
                            hintText: 'Email',
                            fillColor: Colors.white,
                            filled: true,
                            suffixIcon: Icon(Icons.email),
                            prefixIcon: Icon(
                              Icons.alternate_email_outlined,
                              color: Colors.indigoAccent,
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: const Color(0xffE4E7EB)),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderSide:
                                  const BorderSide(color: Colors.indigoAccent),
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 10),
                        child: TextFormField(
                          decoration: InputDecoration(
                            hintText: 'Phone no',
                            fillColor: Colors.white,
                            filled: true,
                            prefixIcon: Icon(
                              Icons.add_call,
                              color: Colors.indigoAccent,
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: const Color(0xffE4E7EB)),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderSide:
                                  const BorderSide(color: Colors.indigoAccent),
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 10),
                        child: TextFormField(
                          decoration: InputDecoration(
                            hintText: 'Sap id',
                            fillColor: Colors.white,
                            filled: true,
                            prefixIcon: Icon(
                              Icons.numbers,
                              color: Colors.indigoAccent,
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: const Color(0xffE4E7EB)),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderSide:
                                  const BorderSide(color: Colors.indigoAccent),
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 10),
                        child: TextFormField(
                          decoration: InputDecoration(
                            hintText: 'Address',
                            fillColor: Colors.white,
                            filled: true,
                            prefixIcon: Icon(
                              Icons.home,
                              color: Colors.indigoAccent,
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: const Color(0xffE4E7EB)),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderSide:
                                  const BorderSide(color: Colors.indigoAccent),
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 10),
                        child: TextFormField(
                          controller: passwordController,
                          decoration: InputDecoration(
                            hintText: 'Password',
                            fillColor: Colors.white,
                            filled: true,
                            suffixIcon: Icon(Icons.lock),
                            prefixIcon: Icon(
                              Icons.lock_open,
                              color: Colors.indigoAccent,
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: const Color(0xffE4E7EB)),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderSide:
                                  const BorderSide(color: Colors.indigoAccent),
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 10),
                        child: TextFormField(
                          decoration: InputDecoration(
                            hintText: 'Confirm Password',
                            fillColor: Colors.white,
                            filled: true,
                            suffixIcon: Icon(Icons.lock),
                            prefixIcon: Icon(
                              Icons.lock_open,
                              color: Colors.indigoAccent,
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: const Color(0xffE4E7EB)),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderSide:
                                  const BorderSide(color: Colors.indigoAccent),
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                        ),
                      ),
                      // Rest of the code...

                      GestureDetector(
                        child: Container(
                          height: 50,
                          width: 180,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: Colors.indigo,
                          ),
                          child: ElevatedButton(
                            onPressed: () {
                              Authcontroller.instance.register(
                                  emailController.text.trim(),
                                  passwordController.text.trim());
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => login(),
                                    transition: Transition.zoom),
                              );
                            },
                            child: const Center(
                              child: Text(
                                'Create Account',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontSize: 18,
                                  fontFamily: "Oswald",
                                  color: Colors.white,
                                ),
                              ),
                            ),
                            // ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class TrianglePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    var path = Path();
    path.lineTo(size.width / 0.5, 0);

    var controlPoint = Offset(size.width * 0.50, size.height * 0.55);
    var endPoint = Offset(0, size.height / 3.80);

    path.quadraticBezierTo(
      controlPoint.dx,
      controlPoint.dy,
      endPoint.dx,
      endPoint.dy,
    );

    var paint = Paint()
      ..color = Colors.blue
      ..style = PaintingStyle.fill;

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(TrianglePainter oldDelegate) => false;
}
