import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:test_project/UI/Module/Bus%20Booking/Region.dart';
import 'package:test_project/UI/registration/auth_controller.dart';
import 'package:test_project/UI/registration/registration.dart';
import 'package:test_project/UI/registration/resetpassword.dart';

class login extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          title: const Text('Login'),
        ),
        body: OppositeTriangle(),
      ),
    );
  }
}

class OppositeTriangle extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return CustomPaint(
        painter: TrianglePainter(),
        child: Stack(
          children: [
            Positioned(
              top: 20,
              left: 120,
              child: Container(
                width: 150,
                height: 150,
                child: Image.asset(
                  'assets/logo.png',
                ),
              ),
            ),
            Positioned(
              top: 300,
              left: 20,
              right: 20,
              child: Column(children: [
                Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  child: TextFormField(
                    decoration: InputDecoration(
                      hintText: 'Email',
                      helperText: 'Enter email e.g jon@gmail.com',
                      fillColor: Colors.white,
                      filled: true,
                      suffixIcon: Icon(Icons.email),
                      prefixIcon: Icon(
                        Icons.alternate_email_outlined,
                        color: Colors.indigoAccent,
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.indigo),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderSide:
                            const BorderSide(color: Colors.indigoAccent),
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  child: TextFormField(
                    obscureText: true,
                    decoration: InputDecoration(
                      hintText: 'Password',
                      fillColor: Colors.white,
                      filled: true,
                      suffixIcon: Icon(Icons.lock),
                      prefixIcon: Icon(
                        Icons.lock_open,
                        color: Colors.indigoAccent,
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.indigoAccent),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderSide:
                            const BorderSide(color: Colors.indigoAccent),
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),
                ),
                GestureDetector(
                  onTap: () {
                    // Handle forget password functionality here
                    // Navigate to a password reset page
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => Resetpassword(),
                      ),
                    );
                  },
                  child: Padding(
                    padding: EdgeInsets.only(left: 115),
                    child: Center(
                      child: Text(
                        'Forget Password',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 18,
                          fontFamily: "Oswald",
                          color: Colors.indigoAccent,
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 25),
                Container(
                  height: 50,
                  width: 200,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: Colors.indigo,
                  ),
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => Region(),
                        ),
                      );
                    },
                    child: const Center(
                      child: Text(
                        'Login',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 18,
                          fontFamily: "Oswald",
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 5),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    RichText(
                      text: TextSpan(
                        text: 'Don\'t have an account? ',
                        style: Theme.of(context).textTheme.bodyText1,
                        children: [
                          TextSpan(
                            text: 'Sign up',
                            style: TextStyle(
                              // decoration: TextDecoration.underline,
                              fontWeight: FontWeight.bold,
                              // fontSize: 18,
                              color: Colors.indigoAccent,
                            ),
                            recognizer: TapGestureRecognizer()
                              ..onTap = () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => registration(),
                                  ),
                                );
                              },
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ]),
            ),
          ],
        ));
  }
}

class TrianglePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    var path = Path();
    path.lineTo(size.width / 0.5, 0);

    var controlPoint = Offset(size.width * 0.50, size.height * 0.55);
    var endPoint = Offset(0, size.height / 3);

    path.quadraticBezierTo(
      controlPoint.dx,
      controlPoint.dy,
      endPoint.dx,
      endPoint.dy,
    );

    var paint = Paint()
      ..color = Colors.blue
      ..style = PaintingStyle.fill;

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(TrianglePainter oldDelegate) => false;
}
