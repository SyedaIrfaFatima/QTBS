import 'package:flutter/material.dart';
import 'package:test_project/UI/registration/login.dart';

import 'forgetpassword.dart';

class Resetpassword extends StatelessWidget {
  const Resetpassword({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Colors.white,
          elevation: 0,
          leading: IconButton(
            icon: Icon(Icons.arrow_back),
            color: Colors.blue,
            onPressed: () {
              Navigator.pop(
                context,
                MaterialPageRoute(
                  builder: (context) => login(),
                ),
              );
            },
          ),
        ),
        body: SafeArea(
          child: Column(children: [
            SizedBox(
              height: 50,
            ),
            Center(
              child: const Image(
                height: 150,
                width: 120,
                image: AssetImage('assets/logo.png'),
              ),
            ),
            Column(
              children: [
                Padding(
                    padding: EdgeInsets.only(right: 150),
                    child: Text(
                      'Rest Your Password',
                      style: TextStyle(
                          fontSize: 20,
                          fontFamily: "Oswald",
                          fontWeight: FontWeight.bold,
                          color: Colors.black),
                    )),
                SizedBox(
                  height: 10,
                ),
                Padding(
                    padding: EdgeInsets.only(left: 30),
                    child: Text(
                      'Need to reset your password? No problem! Just Click the button below',
                      style: TextStyle(
                          fontSize: 14,
                          fontFamily: "Oswald",
                          color: Colors.black),
                    )),
              ],
            ),
            const SizedBox(
              height: 10,
            ),
            Container(
              height: 50,
              width: 250,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: Colors.indigo,
              ),
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => Forgetpass(),
                    ),
                  );
                },
                child: const Center(
                  child: Text(
                    'Rest your Password',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 18,
                      fontFamily: "Oswald",
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ),
          ]),
        ),
      ),
    );
  }
}
