import 'package:flutter/material.dart';

import 'creatpass.dart';
import 'login.dart';

void main() {
  runApp(const Forgetpass());
}

class Forgetpass extends StatelessWidget {
  const Forgetpass({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Colors.white,
          elevation: 0,
          leading: IconButton(
            icon: Icon(Icons.arrow_back),
            color: Colors.blue,
            onPressed: () {
              Navigator.pop(
                context,
                MaterialPageRoute(
                  builder: (context) => login(),
                ),
              );
            },
          ),
        ),
        body: SafeArea(
          child: Column(children: [
            SizedBox(
              height: 50,
            ),
            Center(
              child: const Image(
                height: 150,
                width: 120,
                image: AssetImage('assets/logo.png'),
              ),
            ),

            Column(
              children: [
                Padding(
                    padding: EdgeInsets.only(right: 150),
                    child: Text(
                      'Forget Password',
                      style: TextStyle(
                          fontSize: 20,
                          fontFamily: "Oswald",
                          fontWeight: FontWeight.bold,
                          color: Colors.black),
                    )),
                SizedBox(
                  height: 10,
                ),
                Padding(
                    padding: EdgeInsets.only(left: 30),
                    child: Text(
                      'Enter the email associated with your account',
                      style: TextStyle(
                          fontSize: 14,
                          fontFamily: "Oswald",
                          color: Colors.black),
                    )),
              ],
            ),
            // const Center(
            //   child: Text(
            //     'Ride smarter not harder',
            //         textAlign: TextAlign.start,
            //     style:TextStyle(fontSize: 14, fontFamily: "Oswald", color:Colors.black),
            //   )
            // ),
            SizedBox(
              height: 30,
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: TextFormField(
                decoration: InputDecoration(
                  hintText: 'Email address',
                  fillColor: Colors.white,
                  filled: true,
                  prefixIcon: Icon(
                    Icons.email,
                    color: Color((0Xff323F4B)),
                  ),
                  focusedBorder: OutlineInputBorder(
                      borderSide: const BorderSide(color: Colors.blue),
                      borderRadius: BorderRadius.circular(20)),
                  enabledBorder: OutlineInputBorder(
                      borderSide: const BorderSide(color: Colors.blue),
                      borderRadius: BorderRadius.circular(10)),
                ),
              ),
            ),

            const SizedBox(
              height: 10,
            ),

            const SizedBox(
              height: 30,
            ),

            Container(
              height: 50,
              width: 250,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: Colors.indigo,
              ),
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => crtnewpass(),
                    ),
                  );
                },
                child: const Center(
                  child: Text(
                    'Send verification code',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 18,
                      fontFamily: "Oswald",
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ),
          ]),
        ),
      ),
    );
  }
}
